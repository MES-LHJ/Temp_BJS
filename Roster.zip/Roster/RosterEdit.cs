﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using Roster.Models;

namespace Roster
{
    public partial class RosterEdit : MetroForm
    {
        private string originEmployeeCode;
        public RosterEdit(RosterWorkout model)
        {
            InitializeComponent();
            originEmployeeCode = model.EmployeeCode;
            this.Load += RosterEdit_Load;
            this.PartCode.SelectedIndexChanged += PartCode_SelectedIndexChanged;
            this.Male.CheckedChanged += Male_CheckedChanged_1;
            this.Female.CheckedChanged += Female_CheckedChanged_1;
            this.PhoneNum.TextChanged += PhoneNum_TextChanged;
            this.Save.Click += Save_Click;
            this.Exit.Click += Exit_Click_1;
        }

        public RosterEdit(int model)
        {
            this.model=model;
        }

        private Dictionary<string, string> departmentMap = new Dictionary<string, string>();
        private int model;

        private void RosterEdit_Load(object sender, EventArgs e) // 폼 로드 시 콤보 박스 초기화 및 정렬
        {
            PartCode.Items.Clear(); // 부서 코드 콤보박스 초기화
            departmentMap.Clear();  // 부서명 맵 초기화

            //SqlRepository.RosterCheck();  // 부서조회

            var departments = SqlRepository.GetDepartments() // 부서코드 오름차순 정렬
                .OrderBy(d => d.DepartmentCode);

            PartCode.Items.AddRange(departments.ToArray()); // 부서코드 콤보박스에 파싱
        }

        private void PartCode_SelectedIndexChanged(object sender, EventArgs e) // 부서 코드
        {
            string code = PartCode.SelectedItem?.ToString();
            if (code != null && departmentMap.ContainsKey(code))
            {
                DepartName.Text = departmentMap[code];
            }
            else
            {
                DepartName.Text = string.Empty;
            }
        }

        private void Male_CheckedChanged_1(object sender, EventArgs e)
        {
            if (Male.Checked) Female.Checked = false;
        }

        private void Female_CheckedChanged_1(object sender, EventArgs e)
        {
            if (Female.Checked) Male.Checked = false;
        }

        private void PhoneNum_TextChanged(object sender, EventArgs e) // 휴대전화 번호 포맷팅
        {
            // 현재 커서 위치 저장
            int oldSelectionStart = PhoneNum.SelectionStart;
            int oldLength = PhoneNum.Text.Length;

            // 숫자만 추출 (최대 11자리로 제한)
            string digits = new string(PhoneNum.Text.Where(char.IsDigit).ToArray());
            if (digits.Length > 11)
                digits = digits.Substring(0, 11);

            // 010으로 시작하고 11자리 이하일 때만 포맷 적용
            string formatted = digits;
            if (digits.StartsWith("010"))
            {
                if (digits.Length > 7)
                    formatted = $"{digits.Substring(0, 3)}-{digits.Substring(3, 4)}-{digits.Substring(7)}";
                else if (digits.Length > 3)
                    formatted = $"{digits.Substring(0, 3)}-{digits.Substring(3)}";
            }
            else
            {
                formatted = digits;
            }

            // 값이 다를 때만 갱신 (무한루프 방지)
            if (PhoneNum.Text != formatted)
            {
                // 하이픈 개수 차이 계산
                int oldHyphenCount = PhoneNum.Text.Take(oldSelectionStart).Count(c => c == '-');
                int newHyphenCount = formatted.Take(oldSelectionStart).Count(c => c == '-');

                PhoneNum.Text = formatted;

                // 커서 위치 보정
                int newSelectionStart = oldSelectionStart + (newHyphenCount - oldHyphenCount);
                PhoneNum.SelectionStart = Math.Max(0, Math.Min(newSelectionStart, PhoneNum.Text.Length));
            }
        }

        public RosterWorkout SavedModel { get; private set; }

        private void Save_Click(object sender, EventArgs e) // 저장 버튼
        {
            if (string.IsNullOrWhiteSpace(PartCode.Text))
            {
                MessageBox.Show("부서코드를 입력해주세요.");
                PartCode.Focus();
                PartCode.SelectAll();
                return;
            }
            if (string.IsNullOrWhiteSpace(EmployeeCo.Text))
            {
                MessageBox.Show("사원코드를 입력해주세요.");
                EmployeeCo.Focus();
                EmployeeCo.SelectAll();
                return;
            }
            if (string.IsNullOrWhiteSpace(EmployeeName.Text))
            {
                MessageBox.Show("사원명을 입력해주세요.");
                EmployeeName.Focus();
                EmployeeName.SelectAll();
                return;
            }

            if (!RosterAdd.IsValidEmail(Email.Text))
            {
                MessageBox.Show("올바른 이메일 형식이 아닙니다.");
                Email.Focus();
                Email.SelectAll();
                return;
            }

            try
            {
                //SqlRepository.UpdateEmployee(this);
                //SqlRepository.UpdateEmployee(originEmployeeCode, SavedModel);
                SavedModel = new RosterWorkout
                {
                    DepartmentCode = PartCode.Text,
                    EmployeeCode = EmployeeCo.Text,
                    EmployeeName = EmployeeName.Text,
                    Position = Position.Text,
                    Employment = Form_of_employment.Text,
                    Email = Email.Text,
                    PhoneNum = PhoneNum.Text,
                    Gender = Male.Checked ? RosterAdd.Gender.Male : RosterAdd.Gender.Female,
                    MessengerID = MessengerId.Text,
                    Memo = Memo.Text,
                };

                    MessageBox.Show("수정 되었습니다.");
                this.DialogResult = DialogResult.OK;
                this.Close(); // 폼 닫기
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }

        private void Exit_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
