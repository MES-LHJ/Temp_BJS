﻿using MetroFramework.Forms;
using Roster.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Roster
{
    public partial class RosterDelete : MetroForm
    {
        private readonly RosterWorkout roster;
        public RosterDelete(RosterWorkout roster)
        {
            InitializeComponent();
            this.Delete.Click += Delete_Click;
            this.Cancel.Click += Cancel_Click;

            RosterCode.Text = roster.EmployeeCode;
            RosterName.Text = roster.EmployeeName;
        }

        

        private void Delete_Click(object sender, EventArgs e)
        {
            try
            {
                SqlRepository.DeleteEmployee(employee.EmployeeId);
                MessageBox.Show("삭제되었습니다.");
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Close(); // 폼 닫기
        }
    }
}
