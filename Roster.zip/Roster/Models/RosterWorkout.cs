﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Roster.RosterAdd;

namespace Roster
{
    public class RosterWorkout
    {
        public long DepartmentId { get; set; }
        public long EmployeeId { get; set; }
        [DisplayName("부서코드")]
        public string DepartmentCode { get; set; }
        [DisplayName("부서명")]
        public string DepartmentName { get; set; }
        [DisplayName("사원코드")]
        public string EmployeeCode { get; set; }
        [DisplayName("사원명")]
        public string EmployeeName { get; set; }
        [DisplayName("아이디")]
        public string ID { get; set; }
        [DisplayName("비밀번호")]
        public string Password { get; set; }
        [DisplayName("직급")]
        public string Position { get; set; }
        [DisplayName("고용형태")]
        public string Employment { get; set; }
        [DisplayName("성별")]
        public RosterAdd.Gender Gender { get; set; }
        [DisplayName("전화번호")]
        public string PhoneNum { get; set; }
        [DisplayName("이메일")]
        public string Email { get; set; }
        [DisplayName("메신저ID")]
        public string MessengerID { get; set; }
        [DisplayName("메모")]
        public string Memo { get; set; }
        [DisplayName("사원이미지")]
        public string PhotoPath { get; set; }

        public static class GridHeaderConst
        {
            public const string DepartmentCode = "부서코드";
            public const string DepartmentName = "부서명";
            public const string EmployeeCode = "사원코드";
            public const string EmployeeName = "사원명";
            public const string Id = "아이디";
            public const string Password = "비밀번호";
            public const string Position = "직급";
            public const string Employment = "고용형태";
            public const string Gender = "성별";
            public const string PhoneNum = "전화번호";
            public const string Email = "email";
            public const string MessengerID = "메신저ID";
            public const string Memo = "메모";
            public const string PhonePath = "path";
        }

        public static RosterWorkout Reader(SqlDataReader reader)
        {
            return new RosterWorkout
            {
                DepartmentId   = Convert.ToInt64(reader["DepartmentId"]),
                DepartmentCode = reader["DepartmentCode"].ToString(),
                DepartmentName = reader["DepartmentName"].ToString(),
                EmployeeId     = Convert.ToInt64(reader["EmployeeId"]),
                EmployeeCode   = reader["EmployeeCode"].ToString(),
                EmployeeName   = reader["EmployeeName"].ToString(),
                ID             = reader["ID"].ToString(),
                Password       = reader["Password"].ToString(),
                Position       = reader["Position"].ToString(),
                Employment     = reader["Employment"].ToString(),
                Gender         = Enum.TryParse<RosterAdd.Gender>(
                                    reader["Gender"].ToString(),
                                    out var g) ? g : RosterAdd.Gender.Male,
                PhoneNum       = reader["PhoneNum"].ToString(),
                Email          = reader["Email"].ToString(),
                MessengerID    = reader["MessengerID"].ToString(),
                Memo           = reader["Memo"].ToString(),
                PhotoPath      = reader["PhotoPath"].ToString()
            };
        }

    }
}
